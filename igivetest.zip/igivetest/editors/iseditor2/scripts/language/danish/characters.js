function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "HTML Kode";
    document.getElementById("btnClose").value = "Luk";
    }
function writeTitle()
    {
    document.write("<title>Symboler</title>")
    }