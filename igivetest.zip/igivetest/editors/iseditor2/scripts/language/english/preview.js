function loadTxt()
    {
    document.getElementById("btnClose").value = "close";
    }
function writeTitle()
    {
    document.write("<title>Preview</title>")
    }